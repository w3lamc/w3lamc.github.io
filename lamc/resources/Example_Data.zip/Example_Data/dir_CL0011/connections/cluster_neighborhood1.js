
var redraw, g, renderer;

/* only do all this when document has finished loading (needed for RaphaelJS) */
window.onload = function() {

    var width = $(document).width() - 50;
    var height = $(document).height() - 50;

    var render = function(r, n) {
        
        frame = r.circle(n.point[0], n.point[1], n.size);
        frame.attr({
            "fill": n.fill , 
            "stroke-width" : (n.distance === 0 ? "3px" : "1px")
          });
        var set = r.set()
          .push(
            frame ,
			r.text(n.point[0],n.point[1],(n.label || n.id))
          );
        
        
        set.hover(function(){ label.animate({opacity:1,"fill-opacity":1}, 500); }, function(){ label.animate({opacity:0},300); });
        tooltip = r.set()
        .push(
            r.rect(0, 0, 90, 30).attr({"fill": "#fec", "stroke-width": 1, r : "9px"})
        ).push(
            r.text(25, 15, (n.label || n.id)
                    + "\n" + (n.counts === undefined ? "Infinity" : n.counts) ).attr({"fill": "#000000"})
        );
	    for(i in set.items) {
	        set.items[i].tooltip(tooltip);
	    };

        return set;
      };

    
    g = new Graph();
g.addNode("CL11", { render : render, counts : "3987" , size : "8.60064623566239" , fill : "#f00"});
g.addNode("CL190", { render : render, counts : "54" , size : "6.73239375982297" , fill : "#0f0"});
g.addNode("CL98", { render : render, counts : "307" , size : "7.48713837547719" , fill : "#0f0"});
g.addNode("CL57", { render : render, counts : "1159" , size : "8.0640834359636" , fill : "#0f0"});

g.addEdge("CL11", "CL190", {stroke : "#888", label : "1", fill : "#999"});
g.addEdge("CL11", "CL98", {stroke : "#888", label : "18", fill : "#000"});
g.addEdge("CL11", "CL57", {stroke : "#888", label : "5", fill : "#555"});

var layouter = new Graph.Layout.Spring(g);
g.nodes.CL11.layoutPosX = -0.611548754073
g.nodes.CL190.layoutPosX = -2.84882926956724
g.nodes.CL98.layoutPosX = 3.26515973884941
g.nodes.CL57.layoutPosX = -3.44793672002939

g.nodes.CL11.layoutPosY = 7.7017576061151
g.nodes.CL190.layoutPosY = 10.3641799708003
g.nodes.CL98.layoutPosY = 8.38269877622133
g.nodes.CL57.layoutPosY = 4.26462001509186


	g.layoutMinX = -3.447937
	g.layoutMaxX = 3.26516
	g.layoutMinY = 4.26462
	g.layoutMaxY = 10.36418
						
renderer = new Graph.Renderer.Raphael("canvas", g, width, height);
redraw = function() {
        layouter.layout();
        renderer.draw();
 };

};
					
					