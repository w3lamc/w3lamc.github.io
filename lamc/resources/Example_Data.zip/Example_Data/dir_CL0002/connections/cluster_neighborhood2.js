
var redraw, g, renderer;

/* only do all this when document has finished loading (needed for RaphaelJS) */
window.onload = function() {

    var width = $(document).width() - 50;
    var height = $(document).height() - 50;

    var render = function(r, n) {
        
        frame = r.circle(n.point[0], n.point[1], n.size);
        frame.attr({
            "fill": n.fill , 
            "stroke-width" : (n.distance === 0 ? "3px" : "1px")
          });
        var set = r.set()
          .push(
            frame ,
			r.text(n.point[0],n.point[1],(n.label || n.id))
          );
        
        
        set.hover(function(){ label.animate({opacity:1,"fill-opacity":1}, 500); }, function(){ label.animate({opacity:0},300); });
        tooltip = r.set()
        .push(
            r.rect(0, 0, 90, 30).attr({"fill": "#fec", "stroke-width": 1, r : "9px"})
        ).push(
            r.text(25, 15, (n.label || n.id)
                    + "\n" + (n.counts === undefined ? "Infinity" : n.counts) ).attr({"fill": "#000000"})
        );
	    for(i in set.items) {
	        set.items[i].tooltip(tooltip);
	    };

        return set;
      };

    
    g = new Graph();
g.addNode("CL2", { render : render, counts : "5808" , size : "8.76402660769204" , fill : "#f00"});
g.addNode("CL15", { render : render, counts : "3457" , size : "8.53869937954241" , fill : "#0f0"});
g.addNode("CL35", { render : render, counts : "2028" , size : "8.3070679506613" , fill : "#0f0"});
g.addNode("CL32", { render : render, counts : "2139" , size : "8.33021078457153" , fill : "#0f0"});
g.addNode("CL96", { render : render, counts : "342" , size : "7.53402610605614" , fill : "#0f0"});

g.addEdge("CL2", "CL15", {stroke : "#888", label : "892", fill : "#333"});
g.addEdge("CL2", "CL35", {stroke : "#888", label : "5464", fill : "#000"});
g.addEdge("CL15", "CL32", {stroke : "#888", label : "40", fill : "#888"});
g.addEdge("CL15", "CL96", {stroke : "#888", label : "10", fill : "#bbb"});
g.addEdge("CL35", "CL32", {stroke : "#888", label : "537", fill : "#444"});

var layouter = new Graph.Layout.Spring(g);
g.nodes.CL2.layoutPosX = 10.552665010767
g.nodes.CL15.layoutPosX = 19.8593940120207
g.nodes.CL35.layoutPosX = 6.94622992445533
g.nodes.CL32.layoutPosX = 16.3494814731839
g.nodes.CL96.layoutPosX = 22.8837308102712

g.nodes.CL2.layoutPosY = 43.0915894904922
g.nodes.CL15.layoutPosY = 40.4464032800539
g.nodes.CL35.layoutPosY = 49.1279833240879
g.nodes.CL32.layoutPosY = 48.5673819011516
g.nodes.CL96.layoutPosY = 28.7892554527946


	g.layoutMinX = 6.94623
	g.layoutMaxX = 22.88373
	g.layoutMinY = 28.78926
	g.layoutMaxY = 49.12798
						
renderer = new Graph.Renderer.Raphael("canvas", g, width, height);
redraw = function() {
        layouter.layout();
        renderer.draw();
 };

};
					
					