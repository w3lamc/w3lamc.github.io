
var redraw, g, renderer;

/* only do all this when document has finished loading (needed for RaphaelJS) */
window.onload = function() {

    var width = $(document).width() - 50;
    var height = $(document).height() - 50;

    var render = function(r, n) {
        
        frame = r.circle(n.point[0], n.point[1], n.size);
        frame.attr({
            "fill": n.fill , 
            "stroke-width" : (n.distance === 0 ? "3px" : "1px")
          });
        var set = r.set()
          .push(
            frame ,
			r.text(n.point[0],n.point[1],(n.label || n.id))
          );
        
        
        set.hover(function(){ label.animate({opacity:1,"fill-opacity":1}, 500); }, function(){ label.animate({opacity:0},300); });
        tooltip = r.set()
        .push(
            r.rect(0, 0, 90, 30).attr({"fill": "#fec", "stroke-width": 1, r : "9px"})
        ).push(
            r.text(25, 15, (n.label || n.id)
                    + "\n" + (n.counts === undefined ? "Infinity" : n.counts) ).attr({"fill": "#000000"})
        );
	    for(i in set.items) {
	        set.items[i].tooltip(tooltip);
	    };

        return set;
      };

    
    g = new Graph();
g.addNode("CL65", { render : render, counts : "973" , size : "7.98811284026835" , fill : "#f00"});
g.addNode("CL24", { render : render, counts : "2677" , size : "8.42764837118693" , fill : "#0f0"});

g.addEdge("CL65", "CL24", {stroke : "#888", label : "2", fill : "#000"});

var layouter = new Graph.Layout.Spring(g);
g.nodes.CL65.layoutPosX = 0.156280278074937
g.nodes.CL24.layoutPosX = -0.479556225086943

g.nodes.CL65.layoutPosY = 0.834858424619949
g.nodes.CL24.layoutPosY = -0.274195045356816


	g.layoutMinX = -0.4795562
	g.layoutMaxX = 0.1562803
	g.layoutMinY = -0.274195
	g.layoutMaxY = 0.8348584
						
renderer = new Graph.Renderer.Raphael("canvas", g, width, height);
redraw = function() {
        layouter.layout();
        renderer.draw();
 };

};
					
					